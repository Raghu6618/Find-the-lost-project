document.addEventListener('DOMContentLoaded', () => {

    function getItems(key) {
        const items = localStorage.getItem(key);
        return items ? JSON.parse(items) : [];
    }

    function saveChat(chatKey, message) {
        const chats = getItems(chatKey);
        chats.push(message);
        localStorage.setItem(chatKey, JSON.stringify(chats));
    }

    function getChatKey(lostEmail, foundEmail) {
        return `chat_${lostEmail}_${foundEmail}`;
    }

    // Open chat with bubbles, timestamps, and simulated other replies
    function openChat(lostItem, foundItem) {
        const chatKey = getChatKey(lostItem.email, foundItem.email);
        const chatId = `chatBox_${chatKey}`;
        let chatBox = document.getElementById(chatId);

        if (!chatBox) {
            chatBox = document.createElement('div');
            chatBox.id = chatId;
            chatBox.classList.add('chat-box');

            const header = document.createElement('div');
            header.classList.add('chat-box-header');
            header.innerText = `Chat: ${lostItem.fullName} ↔ ${foundItem.fullName}`;
            chatBox.appendChild(header);

            const messages = document.createElement('div');
            messages.classList.add('chat-messages');
            chatBox.appendChild(messages);

            const inputContainer = document.createElement('div');
            inputContainer.classList.add('chat-input-container');

            const input = document.createElement('input');
            input.type = 'text';
            input.placeholder = 'Type a message...';

            const sendBtn = document.createElement('button');
            sendBtn.innerText = 'Send';

            const imgInput = document.createElement('input');
            imgInput.type = 'file';
            imgInput.accept = 'image/*';
            imgInput.style.display = 'none';

            const imgBtn = document.createElement('button');
            imgBtn.innerText = '📷';
            imgBtn.onclick = () => imgInput.click();

            inputContainer.appendChild(input);
            inputContainer.appendChild(sendBtn);
            inputContainer.appendChild(imgBtn);
            inputContainer.appendChild(imgInput);
            chatBox.appendChild(inputContainer);

            document.body.appendChild(chatBox);

            // Load previous messages
            const previousChats = getItems(chatKey);
            previousChats.forEach(msg => appendMessage(messages, msg));

            // Send text
            sendBtn.onclick = () => {
                if (input.value.trim() !== '') {
                    const msg = { type: 'text', sender: 'You', text: input.value, timestamp: new Date().toLocaleTimeString() };
                    saveChat(chatKey, msg);
                    appendMessage(messages, msg);
                    input.value = '';
                }
            };

            // Send image
            imgInput.onchange = e => {
                const file = e.target.files[0];
                if (file && file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.readAsDataURL(file);
                    reader.onloadend = () => {
                        const msg = { type: 'image', sender: 'You', image: reader.result, timestamp: new Date().toLocaleTimeString() };
                        saveChat(chatKey, msg);
                        appendMessage(messages, msg);
                    };
                }
                imgInput.value = '';
            };

            // Simulate "other" user replying periodically
            setInterval(() => {
                const allChats = getItems(chatKey);
                const lastMsg = allChats[allChats.length - 1];
                if (!lastMsg || lastMsg.sender !== 'Other') return; // Only reply after user message

                // Random chance to reply
                if (Math.random() < 0.3) {
                    const replyText = generateAutoReply();
                    const msg = { type: 'text', sender: 'Other', text: replyText, timestamp: new Date().toLocaleTimeString() };
                    saveChat(chatKey, msg);
                    appendMessage(messages, msg);
                }
            }, 4000); // every 4 seconds
        }
    }

    function appendMessage(container, msg) {
        const div = document.createElement('div');
        div.classList.add('message');
        div.classList.add(msg.sender === 'You' ? 'you' : 'other');

        if (msg.type === 'text') {
            div.innerText = msg.text;
        } else if (msg.type === 'image') {
            const img = document.createElement('img');
            img.src = msg.image;
            div.appendChild(img);
        }

        const timestamp = document.createElement('div');
        timestamp.classList.add('timestamp');
        timestamp.innerText = msg.timestamp || '';
        div.appendChild(timestamp);

        container.appendChild(div);
        container.scrollTop = container.scrollHeight;
    }

    // Simulated auto replies for fun
    function generateAutoReply() {
        const replies = [
            "Thanks for the info!",
            "I think I found your item.",
            "Could you send a picture?",
            "Where did you find it exactly?",
            "I'll contact you soon.",
            "Can you provide more details?",
            "Got it, thanks!",
            "Looking into it now."
        ];
        return replies[Math.floor(Math.random() * replies.length)];
    }

    // Example: to test chat manually
    // openChat({fullName: 'Alice', email:'alice@example.com'}, {fullName:'Bob', email:'bob@example.com'});
});
