// Mobile Menu Toggle
// const menuToggle = document.getElementById("menu-toggle");
// const navLinks = document.querySelector(".nav-links");
// const searchLogin = document.querySelector(".search-login");

// menuToggle.addEventListener("click", () => {
//   navLinks.classList.toggle("active");
//   searchLogin.classList.toggle("active");
// });

// 

    const menuToggle = document.getElementById('menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });


const items = [
  {
    title: "Brown Leather Wallet",
    status: "lost",
    category: "Wallets",
    description: "Lost a brown leather wallet with several cards and some cash.",
    location: "Central Park, Patna",
    date: "2025-10-26",
    image: "https://cdn.shopify.com/s/files/1/2372/2167/products/OP_0350-s.jpg?v=1565724821",
    action: "View Details"
  },
  {
    title: "Silver Watch",
    status: "found",
    category: "Jewelry",
    description: "Found a silver wristwatch near the university library entrance.",
    location: " Library, Boston",
    date: "2025-10-25",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80",
    action: "Contact Finder"
  },
  {
    title: "Blue Backpack",
    status: "lost",
    category: "Bags",
    description: "Missing a navy blue backpack, contains textbooks and a laptop.",
    location: "Metro Station, Kolkata",
    date: "2023-10-24",
    image: "https://rivacase.com/images/virtuemart/product/5561_blue.4260403577059.ver01.jpg",
  },
  {
    title: "Black Smartphone",
    status: "found",
    category: "Electronics",
    description: "Found a black smartphone, screen is cracked, no case.",
    location: "Coffee Shop, Delhi",
    date: "2023-10-23",
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=600&q=80",
    action: "Contact Finder"
  },
  {
    title: "Reading Glasses",
    status: "lost",
    category: "Eyewear",
    description: "Lost a pair of black-framed reading glasses in a soft case.",
    location: "Public Library, Patna",
    date: "2023-10-22",
    image: "https://www.mensjournal.com/.image/t_share/MTk3MzQ2NDI4NjI3NTkyMzkx/roka-readers.jpg",
    action: "View Details"
  },
  {
    title: "Set of Keys",
    status: "found",
    category: "Keys",
    description: "Found a set of three keys on a silver keyring, no tags.",
    location: "Park Bench, Riverside",
    date: "2023-10-21",
    image:"https://png.pngtree.com/png-vector/20240529/ourlarge/pngtree-set-of-keys-png-image_12535198.png",
    action: "Contact Finder"
  },
  {
    title: "Grey Scarf",
    status: "lost",
    category: "Clothing",
    description: "Lost a soft grey knitted scarf, forgot it at the restaurant.",
    location: "Restaurant, Bedi",
    date: "2025-10-20",
    image: "https://png.pngtree.com/png-clipart/20230701/ourmid/pngtree-gray-scarf-fashion-outwear-illustration-png-image_7399675.png",
    action: "View Details"
  },
  {
    title: "Small Dog (Poodle Mix)",
    status: "found",
    category: "Pets",
    description: "Found a friendly small white poodle mix dog wandering near the park. No collar.",
    location: "Atal Sarovar, Rajkot",
    date: "2025-10-19",
    image: "https://cdn.pixabay.com/photo/2016/01/05/17/51/maltese-1123016_1280.jpg",
    action: "Contact Finder"
  }
];

// Render items
const grid = document.getElementById("items-grid");

items.forEach((item, index) => {
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `
    <img src="${item.image}" alt="${item.title}">
    <div class="card-content">
      <span class="status ${item.status}">${item.status === "lost" ? "Lost Item" : "Found Item"}</span>
      <div class="title">${item.title}</div>
      <div class="category">${item.category}</div>
      <p class="description">${item.description}</p>
      <div class="meta">
        <span>📍 ${item.location}</span>
        <span>📅 ${item.date}</span>
      </div>
      <a href="#" class="btn" data-index="${index}">${item.action}</a>
    </div>
  `;
  grid.appendChild(card);
});

// Modal logic
const modal = document.getElementById("itemModal");
const modalImage = document.getElementById("modalImage");
const modalTitle = document.getElementById("modalTitle");
const modalStatus = document.getElementById("modalStatus");
const modalDescription = document.getElementById("modalDescription");
const modalCategory = document.getElementById("modalCategory");
const modalLocation = document.getElementById("modalLocation");
const modalDate = document.getElementById("modalDate");
const closeBtn = document.querySelector(".close");

document.querySelectorAll(".btn").forEach(btn => {
  btn.addEventListener("click", (e) => {
    e.preventDefault();
    const index = e.target.dataset.index;
    const item = items[index];

    modalImage.src = item.image;
    modalTitle.textContent = item.title;
    modalStatus.textContent = item.status === "lost" ? "Lost Item" : "Found Item";
    modalStatus.style.color = item.status === "lost" ? "#007bff" : "#28a745";
    modalDescription.textContent = item.description;
    modalCategory.textContent = item.category;
    modalLocation.textContent = item.location;
    modalDate.textContent = item.date;

    modal.style.display = "flex";
  });
});

// Close modal
closeBtn.onclick = () => modal.style.display = "none";
window.onclick = (e) => { if (e.target == modal) modal.style.display = "none"; }


function reportLost() {
  alert("Redirecting to Lost Item Report Form...");
  // Replace with actual form page link
  window.location.href = "report-lost.html";
}

function reportFound() {
  alert("Redirecting to Found Item Report Form...");
  // Replace with actual form page link
  window.location.href = "report-found.html";
}

// 
// Sample data
// const itemss = {
//   documents: ["Passport - Black Cover", "Driving License - Ramesh", "College ID Card"],
//   pets: ["Brown Dog near Park", "White Cat with blue collar", "Parrot seen at bus stop"],
//   wallets: ["Black Leather Wallet", "Blue Backpack", "Handbag with floral design"],
//   apparel: ["Red Jacket - Zara", "Blue Cap", "School Uniform"],
//   electronics: ["iPhone 13 Pro", "Dell Laptop Bag", "AirPods Case"],
//   jewelry: ["Gold Chain", "Diamond Ring", "Silver Bracelet"]
// };

// function openCategory(category) {
//   const results = document.getElementById("results");
//   const categoryTitle = document.getElementById("categoryTitle");
//   const itemsList = document.getElementById("itemsList");

//   // Update title
//   categoryTitle.textContent = "Found Items in " + category.charAt(0).toUpperCase() + category.slice(1);

//   // Clear previous list
//   itemsList.innerHTML = "";

//   // Add items dynamically
//   items[category].forEach(item => {
//     const div = document.createElement("div");
//     div.className = "item";
//     div.textContent = item;
//     itemsList.appendChild(div);
//   });

//   results.style.display = "block";
//   results.scrollIntoView({ behavior: "smooth" });
// }

