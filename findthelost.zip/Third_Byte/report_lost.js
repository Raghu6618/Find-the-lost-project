

    const menuToggle = document.getElementById('menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });
// report lost form page

document.addEventListener('DOMContentLoaded', () => {
    const lostItemForm = document.getElementById('lostItemForm');
    const itemPhotoInput = document.getElementById('itemPhoto');
    const photoPreview = document.getElementById('photoPreview');
    const shareLocationToggle = document.getElementById('shareLocation');

    // --- Photo Preview Functionality ---
    if (itemPhotoInput && photoPreview) {
        itemPhotoInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    photoPreview.src = e.target.result;
                    photoPreview.classList.remove('photo-placeholder'); // Remove placeholder class
                    photoPreview.style.objectFit = 'cover'; // Make image cover the preview area
                };
                reader.readAsDataURL(file);
            } else {
                // If no file is selected, reset to placeholder
                photoPreview.src = 'https://via.placeholder.com/100x70?text=No+Image';
                photoPreview.classList.add('photo-placeholder');
                photoPreview.style.objectFit = 'contain'; // Reset object-fit for placeholder
            }
        });
    }

    // --- Share Location Toggle (example, no actual map integration here) ---
    // You could add logic here to show/hide a map embed or related fields
    if (shareLocationToggle) {
        shareLocationToggle.addEventListener('change', function() {
            if (this.checked) {
                console.log('User wants to share approximate location on a map.');
                // Here you would typically initialize a map or show map-related input fields.
            } else {
                console.log('User does not want to share approximate location.');
                // Hide map or related fields.
            }
        });
    }

    // --- Form Submission Functionality ---
    if (lostItemForm) {
        lostItemForm.addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission

            // Gather all form data
            const formData = {
                itemName: document.getElementById('itemName').value,
                itemCategory: document.getElementById('itemCategory').value,
                itemBrand: document.getElementById('itemBrand').value,
                itemColor: document.getElementById('itemColor').value,
                uniqueIdentifier: document.getElementById('uniqueIdentifier').value,
                detailedDescription: document.getElementById('detailedDescription').value,
                lastSeenLocation: document.getElementById('lastSeenLocation').value,
                dateLost: document.getElementById('dateLost').value,
                timeLost: document.getElementById('timeLost').value,
                additionalLocationDetails: document.getElementById('additionalLocationDetails').value,
                shareLocation: document.getElementById('shareLocation').checked,
                fullName: document.getElementById('fullName').value,
                emailAddress: document.getElementById('emailAddress').value,
                phoneNumber: document.getElementById('phoneNumber').value
                // Note: File input (`itemPhoto`) cannot be directly added to a simple JSON
                // It would typically be sent via FormData object in a real AJAX request.
            };

            console.log('Form Data Submitted:', formData);

            // In a real application, you would send this formData to your backend
            // using fetch() or XMLHttpRequest.
            // Example using fetch (requires a server endpoint):
            /*
            fetch('/api/report-lost-item', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
                alert('Lost item report submitted successfully!');
                // You might redirect the user or clear the form here
                lostItemForm.reset(); // Clear the form
                photoPreview.src = 'https://via.placeholder.com/100x70?text=No+Image'; // Reset photo preview
            })
            .catch((error) => {
                console.error('Error:', error);
                alert('Failed to submit report. Please try again.');
            });
            */

            alert('Form submitted! Check console for data.'); // For demonstration
            // Optionally, clear the form after submission for a real app
            // lostItemForm.reset();
            // photoPreview.src = 'https://via.placeholder.com/100x70?text=No+Image';
        });
    }
});


// 
document.addEventListener('DOMContentLoaded', () => {

    function getItems(key) {
        const items = localStorage.getItem(key);
        return items ? JSON.parse(items) : [];
    }

    function saveChat(chatKey, message) {
        const chats = getItems(chatKey);
        chats.push(message);
        localStorage.setItem(chatKey, JSON.stringify(chats));
    }

    function getChatKey(lostEmail, foundEmail) {
        return `chat_${lostEmail}_${foundEmail}`;
    }

    // Open chat with bubbles, timestamps, and simulated other replies
    function openChat(lostItem, foundItem) {
        const chatKey = getChatKey(lostItem.email, foundItem.email);
        const chatId = `chatBox_${chatKey}`;
        let chatBox = document.getElementById(chatId);

        if (!chatBox) {
            chatBox = document.createElement('div');
            chatBox.id = chatId;
            chatBox.classList.add('chat-box');

            const header = document.createElement('div');
            header.classList.add('chat-box-header');
            header.innerText = `Chat: ${lostItem.fullName} ↔ ${foundItem.fullName}`;
            chatBox.appendChild(header);

            const messages = document.createElement('div');
            messages.classList.add('chat-messages');
            chatBox.appendChild(messages);

            const inputContainer = document.createElement('div');
            inputContainer.classList.add('chat-input-container');

            const input = document.createElement('input');
            input.type = 'text';
            input.placeholder = 'Type a message...';

            const sendBtn = document.createElement('button');
            sendBtn.innerText = 'Send';

            const imgInput = document.createElement('input');
            imgInput.type = 'file';
            imgInput.accept = 'image/*';
            imgInput.style.display = 'none';

            const imgBtn = document.createElement('button');
            imgBtn.innerText = '📷';
            imgBtn.onclick = () => imgInput.click();

            inputContainer.appendChild(input);
            inputContainer.appendChild(sendBtn);
            inputContainer.appendChild(imgBtn);
            inputContainer.appendChild(imgInput);
            chatBox.appendChild(inputContainer);

            document.body.appendChild(chatBox);

            // Load previous messages
            const previousChats = getItems(chatKey);
            previousChats.forEach(msg => appendMessage(messages, msg));

            // Send text
            sendBtn.onclick = () => {
                if (input.value.trim() !== '') {
                    const msg = { type: 'text', sender: 'You', text: input.value, timestamp: new Date().toLocaleTimeString() };
                    saveChat(chatKey, msg);
                    appendMessage(messages, msg);
                    input.value = '';
                }
            };

            // Send image
            imgInput.onchange = e => {
                const file = e.target.files[0];
                if (file && file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.readAsDataURL(file);
                    reader.onloadend = () => {
                        const msg = { type: 'image', sender: 'You', image: reader.result, timestamp: new Date().toLocaleTimeString() };
                        saveChat(chatKey, msg);
                        appendMessage(messages, msg);
                    };
                }
                imgInput.value = '';
            };

            // Simulate "other" user replying periodically
            setInterval(() => {
                const allChats = getItems(chatKey);
                const lastMsg = allChats[allChats.length - 1];
                if (!lastMsg || lastMsg.sender !== 'Other') return; // Only reply after user message

                // Random chance to reply
                if (Math.random() < 0.3) {
                    const replyText = generateAutoReply();
                    const msg = { type: 'text', sender: 'Other', text: replyText, timestamp: new Date().toLocaleTimeString() };
                    saveChat(chatKey, msg);
                    appendMessage(messages, msg);
                }
            }, 4000); // every 4 seconds
        }
    }

    function appendMessage(container, msg) {
        const div = document.createElement('div');
        div.classList.add('message');
        div.classList.add(msg.sender === 'You' ? 'you' : 'other');

        if (msg.type === 'text') {
            div.innerText = msg.text;
        } else if (msg.type === 'image') {
            const img = document.createElement('img');
            img.src = msg.image;
            div.appendChild(img);
        }

        const timestamp = document.createElement('div');
        timestamp.classList.add('timestamp');
        timestamp.innerText = msg.timestamp || '';
        div.appendChild(timestamp);

        container.appendChild(div);
        container.scrollTop = container.scrollHeight;
    }

    // Simulated auto replies for fun
    function generateAutoReply() {
        const replies = [
            "Thanks for the info!",
            "I think I found your item.",
            "Could you send a picture?",
            "Where did you find it exactly?",
            "I'll contact you soon.",
            "Can you provide more details?",
            "Got it, thanks!",
            "Looking into it now."
        ];
        return replies[Math.floor(Math.random() * replies.length)];
    }
    //////////////////////////////////////////////////////////////////////////////////////////

    // Example: to test chat manually
    // openChat({fullName: 'Alice', email:'alice@example.com'}, {fullName:'Bob', email:'bob@example.com'});
});

// extra code

// <script>
//     // Function to generate Match ID
//     function generateItemMatchID() {
//       const itemName = document.getElementById('itemName').value.trim().toLowerCase();
//       const itemCategory = document.getElementById('itemCategory').value.trim().toLowerCase();
//       const itemBrand = document.getElementById('itemBrand').value.trim().toLowerCase();
//       const itemColor = document.getElementById('itemColor').value.trim().toLowerCase();
//       const uniqueIdentifier = document.getElementById('uniqueIdentifier').value.trim().toLowerCase();

//       const combined = ${itemName}_${itemCategory}_${itemBrand}_${itemColor}_${uniqueIdentifier};

//       let hash = 0;
//       for (let i = 0; i < combined.length; i++) {
//         hash = (hash << 5) - hash + combined.charCodeAt(i);
//         hash |= 0;
//       }
//       return IM-${Math.abs(hash)};
//     }

//     // Handle form submit
//     const lostItemForm = document.getElementById('lostItemForm');
//     lostItemForm.addEventListener('submit', function(event) {
//       event.preventDefault();

//       const matchID = generateItemMatchID();
//       document.getElementById("matchIdBox").textContent = "Generated Match ID: " + matchID;

//       const formData = {
//         matchID: matchID,
//         itemName: document.getElementById('itemName').value,
//         itemCategory: document.getElementById('itemCategory').value,
//         itemBrand: document.getElementById('itemBrand').value,
//         itemColor: document.getElementById('itemColor').value,
//         uniqueIdentifier: document.getElementById('uniqueIdentifier').value,
//         detailedDescription: document.getElementById('detailedDescription').value,
//         lastSeenLocation: document.getElementById('lastSeenLocation').value,
//         dateLost: document.getElementById('dateLost').value,
//         timeLost: document.getElementById('timeLost').value,
//         additionalLocationDetails: document.getElementById('additionalLocationDetails').value,
//         shareLocation: document.getElementById('shareLocation').checked,
//         fullName: document.getElementById('fullName').value,
//         emailAddress: document.getElementById('emailAddress').value,
//         phoneNumber: document.getElementById('phoneNumber').value
//       };

//       console.log("✅ Match ID Generated:", matchID);
//       console.log("📦 Form Data:", formData);

//       alert(Lost Report Submitted!\nYour Match ID: ${matchID});
//     });
//   </script>
// document.addEventListener("DOMContentLoaded", () => {
//   const form = document.getElementById("lostItemForm");
//   const qrContainer = document.getElementById("qrContainer");

//   form.addEventListener("submit", (e) => {
//     e.preventDefault();

//     // Collect form data
//     const itemName = document.getElementById("itemName").value.trim();
//     const category = document.getElementById("itemCategory").value;
//     const fullName = document.getElementById("fullName").value.trim();
//     const email = document.getElementById("emailAddress").value.trim();

//     // Generate unique ID (timestamp + random string)
//     const uniqueID = "LST-" + Date.now() + "-" + Math.floor(Math.random() * 1000);

//     // Clear previous QR code
//     qrContainer.innerHTML = "";

//     // Generate QR code
//     new QRCode(qrContainer, {
//       text: JSON.stringify({
//         id: uniqueID,
//         item: itemName,
//         category,
//         reporter: fullName,
//         email,
//       }),
//       width: 120,
//       height: 120,
//     });

//     // Save to localStorage (so "found" form can cross-check later)
//     const lostReports = JSON.parse(localStorage.getItem("lostReports")) || [];
//     lostReports.push({
//       id: uniqueID,
//       itemName,
//       category,
//       fullName,
//       email,
//     });
//     localStorage.setItem("lostReports", JSON.stringify(lostReports));

//     alert("Lost Item Report Submitted! Unique ID: " + uniqueID);
//     form.reset();
//   });
// });




// const menuToggle = document.getElementById('menu-toggle');
//   const navLinks = document.querySelector('.nav-links');
//   menuToggle.addEventListener('click', () => {
//     navLinks.classList.toggle('active');
//   });

//   document.addEventListener('DOMContentLoaded', () => {
//     const lostItemForm = document.getElementById('lostItemForm');
//     const itemPhotoInput = document.getElementById('itemPhoto');
//     const photoPreview = document.getElementById('photoPreview');
//     const barcodeModal = document.getElementById('barcodeModal');
//     const barcodeInModal = document.getElementById('barcodeInModal');
//     const closeModal = document.getElementById('closeModal');
//     const barcodeNumberText = document.getElementById('barcodeNumberText');

//     // Photo preview
//     itemPhotoInput.addEventListener('change', function(event) {
//       const file = event.target.files[0];
//       if (file) {
//         const reader = new FileReader();
//         reader.onload = function(e) {
//           photoPreview.src = e.target.result;
//           photoPreview.style.objectFit = 'cover';
//         };
//         reader.readAsDataURL(file);
//       } else {
//         photoPreview.src = 'https://via.placeholder.com/100x70?text=No+Image';
//         photoPreview.style.objectFit = 'contain';
//       }
//     });

//     // Function to generate random barcode
//     function generateRandomBarcode(length = 10) {
//  const chars = '0123456789';
//       let result = '';
//       for (let i = 0; i < length; i++) {
//         result += chars.charAt(Math.floor(Math.random() * chars.length));
//       }
//       return result;
//     }

//     // Form submission
//     lostItemForm.addEventListener('submit', function(event) {
//       event.preventDefault();

//       const randomBarcode = generateRandomBarcode();

//       // Generate barcode in modal
//       JsBarcode("#barcodeInModal", randomBarcode, {
//         format: "CODE128",
//         lineColor: "#000",
//         width: 2,
//         height: 50,
//         displayValue: true
//       });
//       barcodeNumberText.textContent = "Barcode Number: " + randomBarcode;

//       // Store form data in localStorage
//       const formData = {
//         itemName: document.getElementById('itemName').value,
//         itemCategory: document.getElementById('itemCategory').value,
//         itemBrand: document.getElementById('itemBrand').value,
//         itemColor: document.getElementById('itemColor').value,
//         uniqueIdentifier: randomBarcode,
//         detailedDescription: document.getElementById('detailedDescription').value,
//         lastSeenLocation: document.getElementById('lastSeenLocation').value,
//         dateLost: document.getElementById('dateLost').value,
//         timeLost: document.getElementById('timeLost').value,
//         additionalLocationDetails: document.getElementById('additionalLocationDetails').value,
//         shareLocation: document.getElementById('shareLocation').checked,
//         fullName: document.getElementById('fullName').value,
//         emailAddress: document.getElementById('emailAddress').value,
//         phoneNumber: document.getElementById('phoneNumber').value,
//         photo: photoPreview.src
//       };

//       let lostReports = JSON.parse(localStorage.getItem('lostReports')) || [];
//       lostReports.push(formData);
//       localStorage.setItem('lostReports', JSON.stringify(lostReports));

//       // Show modal
//       barcodeModal.style.display = 'flex';

//       // Reset form
//       lostItemForm.reset();
//       photoPreview.src = 'https://via.placeholder.com/100x70?text=No+Image';
//     });

//     // Close modal
//     closeModal.addEventListener('click', () => {
//       barcodeModal.style.display = 'none';
//     });

//     window.addEventListener('click', (e) => {
//       if (e.target === barcodeModal) barcodeModal.style.display = 'none';
//     });
//   });

