// Handle Login Form
document.getElementById("loginForm").addEventListener("submit", function(event) {
  event.preventDefault(); // prevent refresh
  continueAnonymously(); // login behaves same as guest
});

// Continue as Guest (redirect to homepage)
function continueAnonymously() {
  window.location.href = "lost&found.html"; // change to your actual homepage file
}
