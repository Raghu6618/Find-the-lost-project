

// document.addEventListener('DOMContentLoaded', () => {

    
//     function getItems(key) {
//         const items = localStorage.getItem(key);
//         return items ? JSON.parse(items) : [];
//     }

    
//     function saveItem(key, item) {
//         const items = getItems(key);
//         items.push(item);
//         localStorage.setItem(key, JSON.stringify(items));
//     }

    
//     function findMatch(lostItem) {
//         const foundItems = getItems('foundItems');
//         for (let fItem of foundItems) {
            
//             if (
//                 fItem.itemName.toLowerCase() === lostItem.itemName.toLowerCase() &&
//                 fItem.category.toLowerCase() === lostItem.itemCategory.toLowerCase() &&
//                 (lostItem.uniqueIdentifier && fItem.uniqueIdentifier ? 
//                     fItem.uniqueIdentifier.toLowerCase() === lostItem.uniqueIdentifier.toLowerCase() : true)
//             ) {
//                 return fItem; 
//             }
//         }
//         return null;
//     }

    
//     const lostForm = document.getElementById('lostItemForm');
//     if (lostForm) {
//         lostForm.addEventListener('submit', e => {
//             e.preventDefault();

//             const lostData = {
//                 itemName: document.getElementById('itemName').value,
//                 itemCategory: document.getElementById('itemCategory').value,
//                 itemBrand: document.getElementById('itemBrand').value,
//                 itemColor: document.getElementById('itemColor').value,
//                 uniqueIdentifier: document.getElementById('uniqueIdentifier').value,
//                 detailedDescription: document.getElementById('detailedDescription').value,
//                 fullName: document.getElementById('fullName').value,
//                 email: document.getElementById('emailAddress').value,
//                 phone: document.getElementById('phoneNumber').value
//             };

//             const match = findMatch(lostData);

//             if (match) {
//                 alert(`🎉 Match Found! Contact the finder: ${match.fullName} - ${match.email}`);
//                 openChat(lostData, match);
//             } else {
//                 alert('No match found yet. Your lost item has been saved.');
//             }

//             saveItem('lostItems', lostData);
//             lostForm.reset();
//         });
//     }

    
//     const foundForm = document.getElementById('foundItemForm');
//     if (foundForm) {
//         foundForm.addEventListener('submit', e => {
//             e.preventDefault();

//             const foundData = {
//                 itemName: document.getElementById('itemName').value,
//                 category: document.getElementById('category').value,
//                 description: document.getElementById('description').value,
//                 fullName: prompt("Enter your name for contact:"), 
//                 email: prompt("Enter your email for contact:") 
//             };

//             saveItem('foundItems', foundData);

            
//             const lostItems = getItems('lostItems');
//             const matchedLost = lostItems.filter(lItem =>
//                 lItem.itemName.toLowerCase() === foundData.itemName.toLowerCase() &&
//                 lItem.itemCategory.toLowerCase() === foundData.category.toLowerCase()
//             );

//             if (matchedLost.length > 0) {
//                 matchedLost.forEach(lItem => {
//                     alert(`🎉 A lost item matches your found item! Contact owner: ${lItem.fullName} - ${lItem.email}`);
//                     openChat(lItem, foundData);
//                 });
//             } else {
//                 alert('Found item saved. No matching lost items yet.');
//             }

//             foundForm.reset();
//             document.getElementById('photoPreviewContainer').innerHTML = '';
//         });
//     }

    
//     function openChat(lostItem, foundItem) {
//         const chatId = 'chatBox';
//         let chatBox = document.getElementById(chatId);
//         if (!chatBox) {
//             chatBox = document.createElement('div');
//             chatBox.id = chatId;
//             chatBox.style.position = 'fixed';
//             chatBox.style.bottom = '20px';
//             chatBox.style.right = '20px';
//             chatBox.style.width = '300px';
//             chatBox.style.height = '400px';
//             chatBox.style.background = '#fff';
//             chatBox.style.border = '1px solid #333';
//             chatBox.style.borderRadius = '8px';
//             chatBox.style.zIndex = 1000;
//             chatBox.style.display = 'flex';
//             chatBox.style.flexDirection = 'column';
//             chatBox.style.boxShadow = '0 4px 10px rgba(0,0,0,0.3)';
//             document.body.appendChild(chatBox);

//             const header = document.createElement('div');
//             header.innerText = `Chat: ${lostItem.fullName} ↔ ${foundItem.fullName}`;
//             header.style.background = '#007bff';
//             header.style.color = '#fff';
//             header.style.padding = '8px';
//             header.style.textAlign = 'center';
//             chatBox.appendChild(header);

//             const messages = document.createElement('div');
//             messages.style.flex = '1';
//             messages.style.padding = '8px';
//             messages.style.overflowY = 'auto';
//             chatBox.appendChild(messages);

//             const inputContainer = document.createElement('div');
//             inputContainer.style.display = 'flex';
//             inputContainer.style.padding = '8px';
//             const input = document.createElement('input');
//             input.type = 'text';
//             input.placeholder = 'Type a message...';
//             input.style.flex = '1';
//             input.style.padding = '6px';
//             const sendBtn = document.createElement('button');
//             sendBtn.innerText = 'Send';
//             sendBtn.style.marginLeft = '5px';
//             sendBtn.onclick = () => {
//                 if (input.value.trim() !== '') {
//                     const msg = document.createElement('div');
//                     msg.innerText = `You: ${input.value}`;
//                     msg.style.marginBottom = '5px';
//                     messages.appendChild(msg);
//                     messages.scrollTop = messages.scrollHeight;
//                     input.value = '';
//                 }
//             };
//             inputContainer.appendChild(input);
//             inputContainer.appendChild(sendBtn);
//             chatBox.appendChild(inputContainer);
//         }
//     }

// });



document.addEventListener('DOMContentLoaded', () => {

    // Utilities for localStorage
    function getItems(key) {
        const items = localStorage.getItem(key);
        return items ? JSON.parse(items) : [];
    }

    function saveItem(key, item) {
        const items = getItems(key);
        items.push(item);
        localStorage.setItem(key, JSON.stringify(items));
    }

    function saveChat(chatKey, message) {
        const chats = getItems(chatKey);
        chats.push(message);
        localStorage.setItem(chatKey, JSON.stringify(chats));
    }

    function getChatKey(lostEmail, foundEmail) {
        return `chat_${lostEmail}_${foundEmail}`;
    }

    // Find matching found items
    function findMatch(lostItem) {
        const foundItems = getItems('foundItems');
        return foundItems.find(fItem =>
            fItem.itemName.toLowerCase() === lostItem.itemName.toLowerCase() &&
            fItem.category.toLowerCase() === (lostItem.itemCategory || lostItem.category).toLowerCase()
        );
    }

    // Handle Lost Item Form
    const lostForm = document.getElementById('lostItemForm');
    if (lostForm) {
        lostForm.addEventListener('submit', e => {
            e.preventDefault();

            const lostData = {
                itemName: document.getElementById('itemName').value,
                itemCategory: document.getElementById('itemCategory').value,
                uniqueIdentifier: document.getElementById('uniqueIdentifier').value,
                fullName: document.getElementById('fullName').value,
                email: document.getElementById('emailAddress').value
            };

            const match = findMatch(lostData);
            saveItem('lostItems', lostData);

            if (match) {
                alert(`🎉 Match Found! Contact the finder: ${match.fullName} - ${match.email}`);
                openChat(lostData, match);
            } else {
                alert('No match found yet. Your lost item has been saved.');
            }

            lostForm.reset();
        });
    }

    // Handle Found Item Form
    const foundForm = document.getElementById('foundItemForm');
    if (foundForm) {
        foundForm.addEventListener('submit', e => {
            e.preventDefault();

            const foundData = {
                itemName: document.getElementById('itemName').value,
                category: document.getElementById('category').value,
                fullName: prompt("Enter your name for contact:"),
                email: prompt("Enter your email for contact:")
            };

            saveItem('foundItems', foundData);

            const lostItems = getItems('lostItems');
            lostItems.forEach(lItem => {
                if (
                    lItem.itemName.toLowerCase() === foundData.itemName.toLowerCase() &&
                    lItem.itemCategory.toLowerCase() === foundData.category.toLowerCase()
                ) {
                    alert(`🎉 Your found item matches a lost item! Contact owner: ${lItem.fullName} - ${lItem.email}`);
                    openChat(lItem, foundData);
                }
            });

            foundForm.reset();
            document.getElementById('photoPreviewContainer').innerHTML = '';
        });
    }

    // Persistent Chatbox with Images
    function openChat(lostItem, foundItem) {
        const chatKey = getChatKey(lostItem.email, foundItem.email);
        const chatId = `chatBox_${chatKey}`;
        let chatBox = document.getElementById(chatId);

        if (!chatBox) {
            chatBox = document.createElement('div');
            chatBox.id = chatId;
            chatBox.style.position = 'fixed';
            chatBox.style.bottom = '20px';
            chatBox.style.right = '20px';
            chatBox.style.width = '320px';
            chatBox.style.height = '450px';
            chatBox.style.background = '#fff';
            chatBox.style.border = '1px solid #333';
            chatBox.style.borderRadius = '8px';
            chatBox.style.zIndex = 1000;
            chatBox.style.display = 'flex';
            chatBox.style.flexDirection = 'column';
            chatBox.style.boxShadow = '0 4px 10px rgba(0,0,0,0.3)';
            document.body.appendChild(chatBox);

            const header = document.createElement('div');
            header.innerText = `Chat: ${lostItem.fullName} ↔ ${foundItem.fullName}`;
            header.style.background = '#007bff';
            header.style.color = '#fff';
            header.style.padding = '8px';
            header.style.textAlign = 'center';
            chatBox.appendChild(header);

            const messages = document.createElement('div');
            messages.style.flex = '1';
            messages.style.padding = '8px';
            messages.style.overflowY = 'auto';
            chatBox.appendChild(messages);

            const inputContainer = document.createElement('div');
            inputContainer.style.display = 'flex';
            inputContainer.style.padding = '8px';
            inputContainer.style.gap = '5px';

            const input = document.createElement('input');
            input.type = 'text';
            input.placeholder = 'Type a message...';
            input.style.flex = '1';
            input.style.padding = '6px';

            const sendBtn = document.createElement('button');
            sendBtn.innerText = 'Send';

            const imgInput = document.createElement('input');
            imgInput.type = 'file';
            imgInput.accept = 'image/*';
            imgInput.style.display = 'none';

            const imgBtn = document.createElement('button');
            imgBtn.innerText = '📷';
            imgBtn.onclick = () => imgInput.click();

            // Send text message
            sendBtn.onclick = () => {
                if (input.value.trim() !== '') {
                    const msg = { type: 'text', sender: 'You', text: input.value };
                    saveChat(chatKey, msg);
                    appendMessage(messages, msg);
                    input.value = '';
                }
            };

            // Send image message
            imgInput.onchange = e => {
                const file = e.target.files[0];
                if (file && file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.readAsDataURL(file);
                    reader.onloadend = () => {
                        const msg = { type: 'image', sender: 'You', image: reader.result };
                        saveChat(chatKey, msg);
                        appendMessage(messages, msg);
                    };
                }
                imgInput.value = '';
            };

            inputContainer.appendChild(input);
            inputContainer.appendChild(sendBtn);
            inputContainer.appendChild(imgBtn);
            inputContainer.appendChild(imgInput);
            chatBox.appendChild(inputContainer);

            // Load existing messages
            const previousChats = getItems(chatKey);
            previousChats.forEach(msg => appendMessage(messages, msg));
        }
    }

    // Display messages
    function appendMessage(container, msg) {
        const div = document.createElement('div');
        div.style.marginBottom = '8px';
        if (msg.type === 'text') {
            div.innerText = `${msg.sender}: ${msg.text}`;
        } else if (msg.type === 'image') {
            div.innerText = `${msg.sender}:`;
            const img = document.createElement('img');
            img.src = msg.image;
            img.style.width = '100%';
            img.style.marginTop = '5px';
            img.style.borderRadius = '5px';
            div.appendChild(img);
        }
        container.appendChild(div);
        container.scrollTop = container.scrollHeight;
    }

});


// chat.js

document.addEventListener('DOMContentLoaded', () => {

    function getItems(key) {
        const items = localStorage.getItem(key);
        return items ? JSON.parse(items) : [];
    }

    function saveChat(chatKey, message) {
        const chats = getItems(chatKey);
        chats.push(message);
        localStorage.setItem(chatKey, JSON.stringify(chats));
    }

    function getChatKey(lostEmail, foundEmail) {
        return `chat_${lostEmail}_${foundEmail}`;
    }

    // Open chat with bubbles, timestamps, and simulated other replies
    function openChat(lostItem, foundItem) {
        const chatKey = getChatKey(lostItem.email, foundItem.email);
        const chatId = `chatBox_${chatKey}`;
        let chatBox = document.getElementById(chatId);

        if (!chatBox) {
            chatBox = document.createElement('div');
            chatBox.id = chatId;
            chatBox.classList.add('chat-box');

            const header = document.createElement('div');
            header.classList.add('chat-box-header');
            header.innerText = `Chat: ${lostItem.fullName} ↔ ${foundItem.fullName}`;
            chatBox.appendChild(header);

            const messages = document.createElement('div');
            messages.classList.add('chat-messages');
            chatBox.appendChild(messages);

            const inputContainer = document.createElement('div');
            inputContainer.classList.add('chat-input-container');

            const input = document.createElement('input');
            input.type = 'text';
            input.placeholder = 'Type a message...';

            const sendBtn = document.createElement('button');
            sendBtn.innerText = 'Send';

            const imgInput = document.createElement('input');
            imgInput.type = 'file';
            imgInput.accept = 'image/*';
            imgInput.style.display = 'none';

            const imgBtn = document.createElement('button');
            imgBtn.innerText = '📷';
            imgBtn.onclick = () => imgInput.click();

            inputContainer.appendChild(input);
            inputContainer.appendChild(sendBtn);
            inputContainer.appendChild(imgBtn);
            inputContainer.appendChild(imgInput);
            chatBox.appendChild(inputContainer);

            document.body.appendChild(chatBox);

            // Load previous messages
            const previousChats = getItems(chatKey);
            previousChats.forEach(msg => appendMessage(messages, msg));

            // Send text
            sendBtn.onclick = () => {
                if (input.value.trim() !== '') {
                    const msg = { type: 'text', sender: 'You', text: input.value, timestamp: new Date().toLocaleTimeString() };
                    saveChat(chatKey, msg);
                    appendMessage(messages, msg);
                    input.value = '';
                }
            };

            // Send image
            imgInput.onchange = e => {
                const file = e.target.files[0];
                if (file && file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.readAsDataURL(file);
                    reader.onloadend = () => {
                        const msg = { type: 'image', sender: 'You', image: reader.result, timestamp: new Date().toLocaleTimeString() };
                        saveChat(chatKey, msg);
                        appendMessage(messages, msg);
                    };
                }
                imgInput.value = '';
            };

            // Simulate "other" user replying periodically
            setInterval(() => {
                const allChats = getItems(chatKey);
                const lastMsg = allChats[allChats.length - 1];
                if (!lastMsg || lastMsg.sender !== 'Other') return; // Only reply after user message

                // Random chance to reply
                if (Math.random() < 0.3) {
                    const replyText = generateAutoReply();
                    const msg = { type: 'text', sender: 'Other', text: replyText, timestamp: new Date().toLocaleTimeString() };
                    saveChat(chatKey, msg);
                    appendMessage(messages, msg);
                }
            }, 4000); // every 4 seconds
        }
    }

    function appendMessage(container, msg) {
        const div = document.createElement('div');
        div.classList.add('message');
        div.classList.add(msg.sender === 'You' ? 'you' : 'other');

        if (msg.type === 'text') {
            div.innerText = msg.text;
        } else if (msg.type === 'image') {
            const img = document.createElement('img');
            img.src = msg.image;
            div.appendChild(img);
        }

        const timestamp = document.createElement('div');
        timestamp.classList.add('timestamp');
        timestamp.innerText = msg.timestamp || '';
        div.appendChild(timestamp);

        container.appendChild(div);
        container.scrollTop = container.scrollHeight;
    }

    // Simulated auto replies for fun
    function generateAutoReply() {
        const replies = [
            "Thanks for the info!",
            "I think I found your item.",
            "Could you send a picture?",
            "Where did you find it exactly?",
            "I'll contact you soon.",
            "Can you provide more details?",
            "Got it, thanks!",
            "Looking into it now."
        ];
        return replies[Math.floor(Math.random() * replies.length)];
    }

    // Example: to test chat manually
    // openChat({fullName: 'Alice', email:'alice@example.com'}, {fullName:'Bob', email:'bob@example.com'});
});
