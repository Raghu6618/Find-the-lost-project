// Sample data representing lost and found items.
// Add this script to your HTML file, preferably at the bottom of the <body> tag.

    const menuToggle = document.getElementById('menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });


const itemsData = [
    {
        id: 1,
        name: 'Set of House Keys',
        status: 'lost',
        category: 'Keys',
        image:'https://images.pexels.com/photos/14721/pexels-photo.jpg?cs=srgb&dl=keys-key-ring-14721.jpg&fm=jpg' ,
        datePosted: new Date('2025-09-20T10:00:00')
    },
    {
        id: 2,
        name: 'Brown Leather Wallet',
        status: 'found',
        category: 'Wallets',
        image: 'https://i5.walmartimages.com/asr/02f9db34-e033-4d22-86e5-05dc02fe14fc_1.4c452fa503271c0e416ce6df6b9da52c.jpeg' ,
        datePosted: new Date('2025-09-22T14:30:00')
    },
    {
        id: 3,
        name: 'Black Smartphone',
        status: 'lost',
        category: 'Electronics',
        image: 'https://miro.medium.com/v2/resize:fit:1000/1*42tXz-9f038Ztoiiqzh93g.jpeg' ,
        datePosted: new Date('2025-09-18T16:45:00')
    },
    {
        id: 4,
        name: 'Navy Blue Backpack',
        status: 'found',
        category: 'Bags',
        image:'https://cdn11.bigcommerce.com/s-3lem6ywgsw/images/stencil/1280x1280/products/5151/16292/3317A1MB-2__11699.1514932546.jpg?c=2' ,
        datePosted: new Date('2025-09-21T09:15:00')
    },
    {
        id: 5,
        name: 'Silver Wristwatch',
        status: 'lost',
        category: 'Accessories',
        image: 'https://tse2.mm.bing.net/th/id/OIP.k-Tc1UoOVCp21-UI5sqnlAHaE5?rs=1&pid=ImgDetMain&o=7&rm=3' ,
        datePosted: new Date('2025-09-19T11:20:00')
    },
    {
        id: 6,
        name: 'Designer Sunglasses',
        status: 'found',
        category: 'Accessories',
        image: 'https://cdn.shopify.com/s/files/1/0193/6253/products/C848-01a_1800x.jpg?v=1575932477' ,
        datePosted: new Date('2025-09-23T15:00:00')
    },
    {
        id: 7,
        name: 'Wireless Earbuds',
        status: 'lost',
        category: 'Electronics',
        image: 'https://m.media-amazon.com/images/I/716gAr0KA6L.jpg' ,
        datePosted: new Date('2025-09-23T08:50:00')
    },
    {
        id: 8,
        name: 'Grey Waterproof Jacket',
        status: 'found',
        category: 'Apparel',
        image:'https://hrd-live.cdn.scayle.cloud/images/147fbcd74c6ee121b2f63c442770e245.jpg?brightness=1&width=922&height=1230&quality=75&bg=ffffff' ,
        datePosted: new Date('2025-09-23T12:05:00')
    },
    {
        id: 9,
        name: 'Classic Bench',
        status: 'lost',
        category: 'Furniture',
        image: 'https://img.freepik.com/premium-photo/classic-elegance-isolated-garden-bench_1111434-70.jpg' ,
        datePosted: new Date('2025-09-17T09:00:00')
    },
    {
        id: 10,
        name: 'Purple Umbrella',
        status: 'lost',
        category: 'Accessories',
        image: 'https://thumbs.dreamstime.com/b/ai-generated-illustration-vibrant-purple-umbrella-stands-out-against-clean-white-background-creating-visually-303885654.jpg' ,
        datePosted: new Date('2025-09-21T11:00:00')
    },
    {
        id: 11,
        name: 'Denim Jacket',
        status: 'found',
        category: 'Apparel',
        image: 'https://i5.walmartimages.com/asr/1189074f-23a4-4865-b786-b2ade7e08199.5cdbf44c1f043e35adacb4bdc01ad645.jpeg' ,
        datePosted: new Date('2025-09-24T10:00:00')
    },
    {
        id: 12,
        name: 'Bluetooth Headphones',
        status: 'found',
        category: 'Electronics',
        image: 'https://i5.walmartimages.com/seo/Symphonized-Blast-Wireless-Bluetooth-Headphones-Mic-Over-Ear-Samsung-More-22-Playtime-Hours-Travel-Work-Deep-Bass-Noise-Isolation-Red_78ff8e5b-5570-4eb2-8ca0-422e4a64d51e.a392ad46e96f707de61a5547318e70d1.jpeg' ,
        datePosted: new Date('2025-09-24T11:00:00')
    },
];

// Get references to key DOM elements
const applyFiltersBtn = document.querySelector('.apply-filters-btn');
const itemGrid = document.querySelector('.item-grid');
const categoryCheckboxes = document.querySelectorAll('input[name="category"]');
const itemTypeRadios = document.querySelectorAll('input[name="itemType"]');
const keywordSearchInput = document.getElementById('keyword-search');
const sortBySelect = document.getElementById('sort-by');

/**
 * Renders the filtered items to the grid.
 * @param {Array} items - The array of item objects to display.
 */
function renderItems(items) {
    itemGrid.innerHTML = ''; // Clear the grid completely

    if (items.length === 0) {
        itemGrid.innerHTML = '<p>No items found matching your criteria.</p>';
        return;
    }

    items.forEach(item => {
        const itemCard = document.createElement('div');
        itemCard.classList.add('item-card');
        const statusClass = item.status === 'lost' ? 'lost' : 'found';

        itemCard.innerHTML = `
            <span class="status-tag ${statusClass}">${item.status.toUpperCase()}</span>
            <img src="${item.image}" alt="${item.name}">
            <h4 class="item-name">${item.name}</h4>
            <p class="item-category">${item.category}</p>
        `;

        itemGrid.appendChild(itemCard);
    });
}

/**
 * Handles the filtering and sorting logic based on user selections.
 */
function handleFilter() {
    const selectedCategories = Array.from(categoryCheckboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.value.toLowerCase());

    const selectedItemType = document.querySelector('input[name="itemType"]:checked').value;
    const keyword = keywordSearchInput.value.toLowerCase();
    const sortBy = sortBySelect.value;

    let filteredItems = itemsData.filter(item => {
        const itemCategoryLower = item.category.toLowerCase();
        const isCategoryMatch = selectedCategories.length === 0 || selectedCategories.includes(itemCategoryLower);
        
        const isTypeMatch = selectedItemType === 'all' || item.status === selectedItemType;
        const isKeywordMatch = item.name.toLowerCase().includes(keyword) || itemCategoryLower.includes(keyword);

        return isCategoryMatch && isTypeMatch && isKeywordMatch;
    });

    // Sort the filtered items
    if (sortBy === 'newest') {
        filteredItems.sort((a, b) => b.datePosted - a.datePosted);
    } else if (sortBy === 'oldest') {
        filteredItems.sort((a, b) => a.datePosted - b.datePosted);
    } else if (sortBy === 'name') {
        filteredItems.sort((a, b) => a.name.localeCompare(b.name));
    }

    renderItems(filteredItems);
}

// Attach event listeners
applyFiltersBtn.addEventListener('click', handleFilter);
keywordSearchInput.addEventListener('input', handleFilter);
sortBySelect.addEventListener('change', handleFilter);

// Initial rendering of all items when the page loads
handleFilter();