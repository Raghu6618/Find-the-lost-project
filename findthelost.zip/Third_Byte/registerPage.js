// Handle Register Form
document.getElementById("registerForm")?.addEventListener("submit", function(event) {
  event.preventDefault();

  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirmPassword").value;

  if (password !== confirmPassword) {
    alert("Passwords do not match!");
    return;
  }

  // For now, just show success message
  alert("Registration successful! Redirecting to login...");
  window.location.href = "loginPage.html"; // redirect to login
});
