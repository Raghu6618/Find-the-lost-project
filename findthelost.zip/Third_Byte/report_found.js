    const menuToggle = document.getElementById('menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });

    document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('foundItemForm');
    const fileUploadBox = document.getElementById('fileUploadBox');
    const photoFile = document.getElementById('photoFile');
    const photoPreviewContainer = document.getElementById('photoPreviewContainer');

    // Prevent default browser behavior for drag-and-drop
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        fileUploadBox.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    // Highlight drop area on drag enter/over
    ['dragenter', 'dragover'].forEach(eventName => {
        fileUploadBox.addEventListener(eventName, () => {
            fileUploadBox.classList.add('dragging');
        }, false);
    });

    // Remove highlight on drag leave/drop
    ['dragleave', 'drop'].forEach(eventName => {
        fileUploadBox.addEventListener(eventName, () => {
            fileUploadBox.classList.remove('dragging');
        }, false);
    });

    // Handle dropped files
    fileUploadBox.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles(files);
    }

    // Handle file selection via click
    fileUploadBox.addEventListener('click', () => {
        photoFile.click();
    });

    photoFile.addEventListener('change', (e) => {
        handleFiles(e.target.files);
    });

    function handleFiles(files) {
        photoPreviewContainer.innerHTML = ''; // Clear previous previews
        [...files].forEach(uploadFile);
    }

    function uploadFile(file) {
        if (!file.type.startsWith('image/')) {
            return;
        }
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onloadend = () => {
            const img = document.createElement('img');
            img.src = reader.result;
            img.classList.add('photo-preview');
            photoPreviewContainer.appendChild(img);
        };
    }

    // Handle form submission
    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const formData = {
            itemName: document.getElementById('itemName').value,
            description: document.getElementById('description').value,
            category: document.getElementById('category').value,
            condition: document.getElementById('condition').value,
            locationFound: document.getElementById('locationFound').value,
            dateFound: document.getElementById('dateFound').value,
            timeFound: document.getElementById('timeFound').value,
            allowContact: document.getElementById('allowContact').checked
        };

        // You would typically send this data to a server using the Fetch API.
        console.log("Found Item Report Data:", formData);
        
        // For demonstration, show an alert and reset the form.
        alert('Found Item Report Submitted! Check the console for data.');
        form.reset();
        photoPreviewContainer.innerHTML = '';
    });
});


// chat.js

document.addEventListener('DOMContentLoaded', () => {

    function getItems(key) {
        const items = localStorage.getItem(key);
        return items ? JSON.parse(items) : [];
    }

    function saveChat(chatKey, message) {
        const chats = getItems(chatKey);
        chats.push(message);
        localStorage.setItem(chatKey, JSON.stringify(chats));
    }

    function getChatKey(lostEmail, foundEmail) {
        return `chat_${lostEmail}_${foundEmail}`;
    }

    // Open chat with bubbles, timestamps, and simulated other replies
    function openChat(lostItem, foundItem) {
        const chatKey = getChatKey(lostItem.email, foundItem.email);
        const chatId = `chatBox_${chatKey}`;
        let chatBox = document.getElementById(chatId);

        if (!chatBox) {
            chatBox = document.createElement('div');
            chatBox.id = chatId;
            chatBox.classList.add('chat-box');

            const header = document.createElement('div');
            header.classList.add('chat-box-header');
            header.innerText = `Chat: ${lostItem.fullName} ↔ ${foundItem.fullName}`;
            chatBox.appendChild(header);

            const messages = document.createElement('div');
            messages.classList.add('chat-messages');
            chatBox.appendChild(messages);

            const inputContainer = document.createElement('div');
            inputContainer.classList.add('chat-input-container');

            const input = document.createElement('input');
            input.type = 'text';
            input.placeholder = 'Type a message...';

            const sendBtn = document.createElement('button');
            sendBtn.innerText = 'Send';

            const imgInput = document.createElement('input');
            imgInput.type = 'file';
            imgInput.accept = 'image/*';
            imgInput.style.display = 'none';

            const imgBtn = document.createElement('button');
            imgBtn.innerText = '📷';
            imgBtn.onclick = () => imgInput.click();

            inputContainer.appendChild(input);
            inputContainer.appendChild(sendBtn);
            inputContainer.appendChild(imgBtn);
            inputContainer.appendChild(imgInput);
            chatBox.appendChild(inputContainer);

            document.body.appendChild(chatBox);

            // Load previous messages
            const previousChats = getItems(chatKey);
            previousChats.forEach(msg => appendMessage(messages, msg));

            // Send text
            sendBtn.onclick = () => {
                if (input.value.trim() !== '') {
                    const msg = { type: 'text', sender: 'You', text: input.value, timestamp: new Date().toLocaleTimeString() };
                    saveChat(chatKey, msg);
                    appendMessage(messages, msg);
                    input.value = '';
                }
            };

            // Send image
            imgInput.onchange = e => {
                const file = e.target.files[0];
                if (file && file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.readAsDataURL(file);
                    reader.onloadend = () => {
                        const msg = { type: 'image', sender: 'You', image: reader.result, timestamp: new Date().toLocaleTimeString() };
                        saveChat(chatKey, msg);
                        appendMessage(messages, msg);
                    };
                }
                imgInput.value = '';
            };

            // Simulate "other" user replying periodically
            setInterval(() => {
                const allChats = getItems(chatKey);
                const lastMsg = allChats[allChats.length - 1];
                if (!lastMsg || lastMsg.sender !== 'Other') return; // Only reply after user message

                // Random chance to reply
                if (Math.random() < 0.3) {
                    const replyText = generateAutoReply();
                    const msg = { type: 'text', sender: 'Other', text: replyText, timestamp: new Date().toLocaleTimeString() };
                    saveChat(chatKey, msg);
                    appendMessage(messages, msg);
                }
            }, 4000); // every 4 seconds
        }
    }

    function appendMessage(container, msg) {
        const div = document.createElement('div');
        div.classList.add('message');
        div.classList.add(msg.sender === 'You' ? 'you' : 'other');

        if (msg.type === 'text') {
            div.innerText = msg.text;
        } else if (msg.type === 'image') {
            const img = document.createElement('img');
            img.src = msg.image;
            div.appendChild(img);
        }

        const timestamp = document.createElement('div');
        timestamp.classList.add('timestamp');
        timestamp.innerText = msg.timestamp || '';
        div.appendChild(timestamp);

        container.appendChild(div);
        container.scrollTop = container.scrollHeight;
    }

    // Simulated auto replies for fun
    function generateAutoReply() {
        const replies = [
            "Thanks for the info!",
            "I think I found your item.",
            "Could you send a picture?",
            "Where did you find it exactly?",
            "I'll contact you soon.",
            "Can you provide more details?",
            "Got it, thanks!",
            "Looking into it now."
        ];
        return replies[Math.floor(Math.random() * replies.length)];
    }

    // Example: to test chat manually
    // openChat({fullName: 'Alice', email:'alice@example.com'}, {fullName:'Bob', email:'bob@example.com'});
});

// extra code


    // // Function to generate Match ID
    // function generateItemMatchID() {
    //   const itemName = document.getElementById('itemName').value.trim().toLowerCase();
    //   const itemCategory = document.getElementById('itemCategory').value.trim().toLowerCase();
    //   const itemBrand = document.getElementById('itemBrand').value.trim().toLowerCase();
    //   const itemColor = document.getElementById('itemColor').value.trim().toLowerCase();
    //   const uniqueIdentifier = document.getElementById('uniqueIdentifier').value.trim().toLowerCase();

    //   const combined = ${itemName}_${itemCategory}_${itemBrand}_${itemColor}_${uniqueIdentifier};

    //   let hash = 0;
    //   for (let i = 0; i < combined.length; i++) {
    //     hash = (hash << 5) - hash + combined.charCodeAt(i);
    //     hash |= 0;
    //   }
    //   return IM-${Math.abs(hash)};
    // }

    // // Handle form submit
    // const lostItemForm = document.getElementById('lostItemForm');
    // lostItemForm.addEventListener('submit', function(event) {
    //   event.preventDefault();

    //   const matchID = generateItemMatchID();
    //   document.getElementById("matchIdBox").textContent = "Generated Match ID: " + matchID;

    //   const formData = {
    //     matchID: matchID,
    //     itemName: document.getElementById('itemName').value,
    //     itemCategory: document.getElementById('itemCategory').value,
    //     itemBrand: document.getElementById('itemBrand').value,
    //     itemColor: document.getElementById('itemColor').value,
    //     uniqueIdentifier: document.getElementById('uniqueIdentifier').value,
    //     detailedDescription: document.getElementById('detailedDescription').value,
    //     lastSeenLocation: document.getElementById('lastSeenLocation').value,
    //     dateLost: document.getElementById('dateLost').value,
    //     timeLost: document.getElementById('timeLost').value,
    //     additionalLocationDetails: document.getElementById('additionalLocationDetails').value,
    //     shareLocation: document.getElementById('shareLocation').checked,
    //     fullName: document.getElementById('fullName').value,
    //     emailAddress: document.getElementById('emailAddress').value,
    //     phoneNumber: document.getElementById('phoneNumber').value
    //   };

    //   console.log("✅ Match ID Generated:", matchID);
    //   console.log("📦 Form Data:", formData);

    //   alert(Lost Report Submitted!\nYour Match ID: ${matchID});
    // });
  

    /////////////////////////////////////////////////////////////////////////////////////////

    // ==========================
// Menu Toggle
// ==========================
// const menuToggle = document.getElementById('menu-toggle');
// const navLinks = document.querySelector('.nav-links');

// menuToggle.addEventListener('click', () => {
//     navLinks.classList.toggle('active');
// });

// // ==========================
// // Found Item Form
// // ==========================
// document.addEventListener('DOMContentLoaded', () => {
//     const form = document.getElementById('foundItemForm');
//     const fileUploadBox = document.getElementById('fileUploadBox');
//     const photoFile = document.getElementById('photoFile');
//     const photoPreviewContainer = document.getElementById('photoPreviewContainer');
//     const qrContainer = document.getElementById('qrCodeContainer');

//     // Prevent default drag/drop behavior
//     ['dragenter','dragover','dragleave','drop'].forEach(eventName => {
//         fileUploadBox.addEventListener(eventName, preventDefaults, false);
//     });
//     function preventDefaults(e){ e.preventDefault(); e.stopPropagation(); }

//     // Highlight on drag
//     ['dragenter','dragover'].forEach(eventName => {
//         fileUploadBox.addEventListener(eventName, () => {
//             fileUploadBox.classList.add('dragging');
//         });
//     });
//     ['dragleave','drop'].forEach(eventName => {
//         fileUploadBox.addEventListener(eventName, () => {
//             fileUploadBox.classList.remove('dragging');
//         });
//     });

//     // Handle file drop
//     fileUploadBox.addEventListener('drop', handleDrop);
//     function handleDrop(e){
//         const dt = e.dataTransfer;
//         const files = dt.files;
//         handleFiles(files);
//     }

//     // Handle click to browse
//     fileUploadBox.addEventListener('click', () => photoFile.click());
//     photoFile.addEventListener('change', (e) => handleFiles(e.target.files));

//     function handleFiles(files){
//         photoPreviewContainer.innerHTML = '';
//         [...files].forEach(uploadFile);
//     }

//     function uploadFile(file){
//         if(!file.type.startsWith('image/')) return;
//         const reader = new FileReader();
//         reader.readAsDataURL(file);
//         reader.onloadend = () => {
//             const img = document.createElement('img');
//             img.src = reader.result;
//             img.classList.add('photo-preview');
//             photoPreviewContainer.appendChild(img);
//         }
//     }

//     // Generate a unique ID
//     function generateID(){
//         return 'FM-' + Date.now() + '-' + Math.floor(Math.random()*1000);
//     }

//     // Save item to localStorage
//     function saveFoundItem(item){
//         const items = JSON.parse(localStorage.getItem('foundItems') || '[]');
//         items.push(item);
//         localStorage.setItem('foundItems', JSON.stringify(items));
//     }

//     // Form submit
//     form.addEventListener('submit', (e)=>{
//         e.preventDefault();

//         const foundData = {
//             id: generateID(),
//             itemName: document.getElementById('itemName').value,
//             description: document.getElementById('description').value,
//             category: document.getElementById('category').value,
//             condition: document.getElementById('condition').value,
//             locationFound: document.getElementById('locationFound').value,
//             dateFound: document.getElementById('dateFound').value,
//             timeFound: document.getElementById('timeFound').value,
//             allowContact: document.getElementById('allowContact').checked,
//             photos: [...photoPreviewContainer.querySelectorAll('img')].map(img => img.src)
//         };

//         saveFoundItem(foundData);

//         // Generate QR Code
//         qrContainer.innerHTML = '';
//         new QRCode(qrContainer, {
//             text: foundData.id, // or use URL if you have a page for item details
//             width: 128,
//             height: 128,
//             colorDark : "#000000",
//             colorLight : "#ffffff",
//             correctLevel : QRCode.CorrectLevel.H
//         });

//         alert('Found Item Report Submitted!\nCheck the QR code below.');
//         form.reset();
//         photoPreviewContainer.innerHTML = '';
//     });
// });
